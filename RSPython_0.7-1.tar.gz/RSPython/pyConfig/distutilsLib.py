from distutils.sysconfig import *
print get_config_vars()['LIBP'] + "/config"
# print get_config_vars()['LIBRARY']
