import sys
print sys.version[0:3]