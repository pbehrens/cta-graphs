#ifndef PYTHON_CALL_H
#define PYTHON_CALL_H

#include "RPythonModule.h"

Rboolean isSForeignReference(PyObject *val);

#endif
