#
#
#
 def rnorm(n):
   return R_rnorm(n)
