import operator;
x = RS.rnorm(10);
reduce( operator.add, x);
